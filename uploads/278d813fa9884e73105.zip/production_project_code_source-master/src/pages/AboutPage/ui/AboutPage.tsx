import React from 'react';

const AboutPage = () => {
    return (
        <div>
            ABOUT PAGE
        </div>
    );
};

export default AboutPage;
