# Knowberry Auth

### Технологии

* MongoDB
* Redis(cache, temporary data storage)
* Manticore(search engine)
* Fastify(web framework)

### Структура проекта

* /lib - код серверной части
* /config - конфигурационные файлы

* #### /lib
    * /controllers - Обработчики запросов(schema included)
    * /databases - Подключение к БД
    * /models - Декларация моделей MongoDB + repository
    * /utils - ....
    * /passport - Стратегии авторизации через Passport.js
    
Деплой через PM2.

Мультиарендность реализована путем смены БД, в зависимости от контекста запроса.
Авторизация между приложениями системы, осуществляется по секретному ключу.
